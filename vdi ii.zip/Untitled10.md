Nama: Amalia Melani Putri
NIM: 122450122

![good 1.png](5495185a-f934-4d2d-a391-463e76ee4627.png)

Good visualization.
1.	Visualisasi di atas menggabungkan diagram dan data dengan baik dan jelas. Dapat dilihat, peta dan diagram menyajikan persebaran data, semakin besar nilainya, maka diagram akan semakin besar. Hal ini memenuhi prinsip pertama, yaitu bentuk diagram sesuai dengan fungsinya.
2.	Penggunaan warna dan variasi ukuran membuat data mudah dibaca. Hal ini memenuhi prinsip pembenaran pilihan.
3.	Desain visualisasi yang sederhana memberikan informasi dengan baik kepada pembaca. Hal ini memenuhi prinsip ketiga, yaitu aksebilitas.
4.	Data memiliki sumber yang jelas dan disajikan secara proposional. Hal ini memenuhi prinsip tidak membohongi pembaca.


![65ccf42ff14d759a662a3de0_b5mwtiOVdKvlVEtg5qMYlXDvEqRtiiWFqZezMKPTpNnHmlDNvdtPtKjzi3njdXvJTxaN9ZpLjWxEOBQrSn2xsK5lyp2dfmp7epHr7FLjcDWHlhax6LwDwUGcjDzbwlJvGlKtsNDG [MConverter.eu].png](c9fd999c-7f75-4e48-ae50-f3f2d8fd21e4.png)


```python
Good visualization.

1.	Pie chart mempresentasikan dengan baik dalam perbandingan data. Memenuhi syarat fungsi dan bentuk.
2.	Pilihan warna merah dan abu-abu untuk membedakan data male dan data female merupakan langkah yang bagus. Perbedaan palet yang membuatnya mudah dibedakan. Memenuhi prinsip pembenaran pilihan.
3.	Penempatan keterangan pie sudah tepat dan menampilkan persentase. Memenuhi prinsip aksesibiliti.
4.	Visualisasi ini tidak akan menipu pembaca, perbandingan pie 91% dan pie 9% cukup seimbang. 

```

![65ccf42ff14d759a662a3de3_87kXu1UB4eaCyl7vVrrOs0_5yd1aXuNe-HI3fliU-7sLCzYOOB6hDzgQRcQgirS3lingbHROwLEshVy-5R8aNT-GnbtWJhF-fCLqQ7nyHPXcYrpYKStch5HJSzoTD4lLgsf_FWDm (1) [MConverter.eu].png](209f6730-81d1-43bf-a9ea-61155d8a5e7d.png)

Bad visualization.
1.	Grafik tersebut digambarkan dengan balon yang memvisualisasikan kekerasan, kejahatan property, dan kemiskinan beberapa negara. Grafik ini hampir memenuhi prinsip fungsi dan bentuk, namun penggambarannya yang tidak rapi, membuat grafiknya sulit untuk dibaca.
2.	Penggunaan grafik ini sudah tepat dalam membandingkan kekerasan, kejahatan properti dan kemiskinan. Poin ini memenuhi prinsip pembenaran pilihan.
3.	Setiap balon diberikan warna dan pola yang berbeda untuk setiap negaranya. Namun, pola yang diberikan cukup sulit dibedakan, terutama untuk audience yang memiliki buta warna. Selain itu, balon yang saling berhimpitan membuat grafik sulit dibaca. Hal ini membuat prinsip aksesibilitas tidak terpenuhi.
4.	Grafik ini memiliki skala yang sedikit ganjil, jika pembaca tidak memahaminya dengan baik, ada kemungkinan akan adanya misunderstanding.


![image-47.png](6d1a38d7-a9ca-4402-8b4b-c416ebce86ba.png)

Bad visualization

1. Visualisasi 3d membuat pembaca sulit untuk membandingkan nilai dari data.
2. Pembaca akan kesulitan untuk membaca ketinggian aktual bar.
3. Audience membutuhkan waktu lebih lama untuk memahami chart.
4. Memungkinkan audience salah paham terhadap data
